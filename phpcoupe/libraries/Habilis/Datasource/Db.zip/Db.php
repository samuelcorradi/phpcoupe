<?php

namespace Habilis\Datasource;

abstract class Db extends \Habilis\Datasource
{

	/*
	* Armazena o ponteiro de conexão.
	*/
	protected $_connection;
	
	/**
	* Pega o handler de conexão ao banco de dados.
	* @access public
	* @return handler Ponteiro para a conexão com o banco.
	*/
	public function getConnection()
	{

		return $this->_connection;

	}
	
	/**
	* Faz consultas ao banco.
	*/
	abstract public function query($sql);
	
	abstract public function listSources();
	
}